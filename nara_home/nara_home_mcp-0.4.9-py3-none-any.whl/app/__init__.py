"""Nara Home MCP package."""
